﻿namespace APITesting
{
    using System.Net;

    using NUnit.Framework;

    using RestSharp;
    using RestSharp.Extensions.MonoHttp;
    using TechTalk.SpecFlow;
    using ContextHelper;
    using ScenarioContextEnum;

    [Binding]
    public class ApiTestsSteps1 : BaseSteps
    {
        /// <summary>
        /// Make a request to 'GET /product/search/V1'
        /// Accept: application/json
        /// Parameters - ?store=1&lang=en&currency=GBP&q=red&offset=0&limit=10
        /// </summary>

        [Given(@"I call Search API without parameter")]
        public void GivenICallSearchApiWithoutParameter()
        {
            this.Request = new RestRequest(Method.GET);                    
            ScenarioContextHelper.SetContextObject<IRestRequest>(RequestKey,this.Request);
        }


        [Then(@"API returns bad request failure response code")]
        public void ThenAPIReturnsBadRequestFailureResponseCode()
        {
            var response = ScenarioContextHelper.GetContextObject<IRestResponse>(ResponseKey);
            Assert.That(response.StatusCode == HttpStatusCode.BadRequest);
        }

        [Given(@"I call Search API without parameter and wrong POST verb")]
        public void GivenICallSearchAPIWithoutParameterAndWrongPOSTVerb()
        {
            this.Request = new RestRequest(Method.POST);
            ScenarioContextHelper.SetContextObject<IRestRequest>(RequestKey, this.Request);
        }

        [Then(@"API returns Forbidden failure response code")]
        public void ThenAPIReturnsForbiddenFailureResponseCode()
        {
            var response = ScenarioContextHelper.GetContextObject<IRestResponse>(ResponseKey);
            Assert.That(response.StatusCode == HttpStatusCode.Forbidden);
        }


        [Given(@"I call Search API without parameter and wrong PUT verb")]
        public void GivenICallSearchAPIWithoutParameterAndWrongPUTVerb()
        {
            this.Request = new RestRequest(Method.PUT);            
            ScenarioContextHelper.SetContextObject<IRestRequest>(RequestKey, this.Request);

        }

        [Then(@"API returns Not Implemented failure response code")]
        public void ThenAPIReturnsNotImplementedFailureResponseCode()
        {
            var response = ScenarioContextHelper.GetContextObject<IRestResponse>(ResponseKey);
            Assert.That(response.StatusCode == HttpStatusCode.NotImplemented);
        }

        [Given(@"I call Search API without parameter and wrong HEAD verb")]
        public void GivenICallSearchAPIWithoutParameterAndWrongHEADVerb()
        {
            this.Request = new RestRequest(Method.HEAD);
            ScenarioContextHelper.SetContextObject<IRestRequest>(RequestKey, this.Request);

        }

        [Then(@"API returns Method Not Allowed failure response code")]
        public void ThenAPIReturnsMethodNotAllowedFailureResponseCode()
        {
            var response = ScenarioContextHelper.GetContextObject<IRestResponse>(ResponseKey);
            Assert.That(response.StatusCode == HttpStatusCode.MethodNotAllowed);
        }


        [Given(@"I call Search API with all the parameters (.*), ""(.*)"", ""(.*)"", ""(.*)"", (.*) and (.*)")]
        public void GivenICallSearchAPIWithAllTheParametersEGBPRedAnd(int store, string lang, string currency, string query, int offset, int limit)
        {
            this.Request = new RestRequest(Method.GET);
            this.Request.AddParameter("store", store, ParameterType.QueryString);
            this.Request.AddParameter("lang", lang, ParameterType.QueryString);
            this.Request.AddParameter("Currency", currency, ParameterType.QueryString);
            this.Request.AddParameter("q", query, ParameterType.QueryString);
            this.Request.AddParameter("offset", offset, ParameterType.QueryString);
            this.Request.AddParameter("limit", limit, ParameterType.QueryString);        
            ScenarioContextHelper.SetContextObject<IRestRequest>(RequestKey, this.Request);
        }
                

        [Then(@"API returns")]
        public void ThenAPIReturns()
        {
            var response = ScenarioContextHelper.GetContextObject<IRestResponse>(ResponseKey);
            Assert.That(response.StatusCode == HttpStatusCode.OK);
        }

        [Given(@"I call Search API with missing store id ""(.*)"", ""(.*)"", ""(.*)"", (.*) and (.*)")]
        public void GivenICallSearchAPIWithMissingStoreIdAnd(string lang, string currency, string query, int offset, int limit)
        {
            this.Request = new RestRequest(Method.GET);           
            this.Request.AddParameter("lang", lang, ParameterType.QueryString);
            this.Request.AddParameter("Currency", currency, ParameterType.QueryString);
            this.Request.AddParameter("q", query, ParameterType.QueryString);
            this.Request.AddParameter("offset", offset, ParameterType.QueryString);
            this.Request.AddParameter("limit", limit, ParameterType.QueryString);
            ScenarioContextHelper.SetContextObject<IRestRequest>(RequestKey, this.Request);
        }

        [Then(@"API returns ERROR_MISSINGSTORE")]
        public void ThenAPIReturnsERROR_MISSINGSTORE()
        {
         
           var response = ScenarioContextHelper.GetContextObject<IRestResponse>(ResponseKey);
           var errorResponse = ScenarioContextHelper.GetContextObject<ErrorResponse>(DataKey);
           Assert.That(response.StatusCode == HttpStatusCode.BadRequest);
           Assert.That(errorResponse.errorCode == ErrorCodeEnum.ERROR_MISSINGSTORE);
           
        }

        [Given(@"I call Search API with missing language (.*), ""(.*)"", ""(.*)"", (.*) and (.*)")]
        public void GivenICallSearchAPIWithMissingLanguageAnd(int store, string currency, string query, int offset, int limit)
        {
            this.Request = new RestRequest(Method.GET);
            this.Request.AddParameter("store", store, ParameterType.QueryString);
            this.Request.AddParameter("Currency", currency, ParameterType.QueryString);
            this.Request.AddParameter("q", query, ParameterType.QueryString);
            this.Request.AddParameter("offset", offset, ParameterType.QueryString);
            this.Request.AddParameter("limit", limit, ParameterType.QueryString);
            ScenarioContextHelper.SetContextObject<IRestRequest>(RequestKey, this.Request);
        }


        [Then(@"API returns ERROR_MISSINGLANGUAGE")]
        public void ThenAPIReturnsERROR_MISSINGLANGUAGE()
        {
            var response = ScenarioContextHelper.GetContextObject<IRestResponse>(ResponseKey);
            var errorResponse = ScenarioContextHelper.GetContextObject<ErrorResponse>(DataKey);
            Assert.That(response.StatusCode == HttpStatusCode.BadRequest);
            Assert.That(errorResponse.errorCode == ErrorCodeEnum.ERROR_MISSINGLANGUAGE);
        }

        [Given(@"I call Search API with missing currency (.*), ""(.*)"", ""(.*)"", (.*) and (.*)")]
        public void GivenICallSearchAPIWithMissingCurrencyAnd(int store, string lang, string query, int offset, int limit)
        {
            this.Request = new RestRequest(Method.GET);
            this.Request.AddParameter("store", store, ParameterType.QueryString);
            this.Request.AddParameter("lang", lang, ParameterType.QueryString);
            this.Request.AddParameter("q", query, ParameterType.QueryString);
            this.Request.AddParameter("offset", offset, ParameterType.QueryString);
            this.Request.AddParameter("limit", limit, ParameterType.QueryString);
            ScenarioContextHelper.SetContextObject<IRestRequest>(RequestKey, this.Request);
        }

        [Then(@"API returns ERROR_MISSINGCURRENCY")]
        public void ThenAPIReturnsERROR_MISSINGCURRENCY()
        {
            var response = ScenarioContextHelper.GetContextObject<IRestResponse>(ResponseKey);
            var errorResponse = ScenarioContextHelper.GetContextObject<ErrorResponse>(DataKey);
            Assert.That(response.StatusCode == HttpStatusCode.BadRequest);
            Assert.That(errorResponse.errorCode == ErrorCodeEnum.ERROR_MISSINGCURRENCY);

        }

        [Given(@"I call Search API with missing query (.*), ""(.*)"", ""(.*)"", (.*) and (.*)")]
        public void GivenICallSearchAPIWithMissingQueryAnd(int store, string lang, string currency, int offset, int limit)
        {
            this.Request = new RestRequest(Method.GET);
            this.Request.AddParameter("store", store, ParameterType.QueryString);
            this.Request.AddParameter("lang", lang, ParameterType.QueryString);
            this.Request.AddParameter("currency", currency, ParameterType.QueryString);
            this.Request.AddParameter("offset", offset, ParameterType.QueryString);
            this.Request.AddParameter("limit", limit, ParameterType.QueryString);
            ScenarioContextHelper.SetContextObject<IRestRequest>(RequestKey, this.Request);
        }

        [Then(@"API returns ERROR_MISSINGQUERY")]
        public void ThenAPIReturnsERROR_MISSINGQUERY()
        {
            var response = ScenarioContextHelper.GetContextObject<IRestResponse>(ResponseKey);
            var errorResponse = ScenarioContextHelper.GetContextObject<ErrorResponse>(DataKey);
            Assert.That(response.StatusCode == HttpStatusCode.BadRequest);
            Assert.That(errorResponse.errorCode == ErrorCodeEnum.ERROR_MISSINGQUERY);

        }


    }
}